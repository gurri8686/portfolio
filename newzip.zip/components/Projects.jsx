"use client";

import React from "react";

export default function Projects() {
  const projects = [
    {
      id: 1,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
    },
    {
      id: 2,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
    },
    {
      id: 3,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
      highlight: true,
    },
    {
      id: 4,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
    },
    {
      id: 5,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
    },
    {
      id: 6,
      title: "Car Rent",
      description:
        "Web-based platform that allows users to search, book, and manage car rentals from various providers, providing a convenient and efficient solution for transportation needs.",
      skills: ["#react", "#node", "#tailwind"],
    },
  ];

  return (
    <section className="bg-[#0f0e1a] py-20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <p className="text-[#F59E0B] text-sm uppercase tracking-wide mb-2">
            My work
          </p>
          <h2 className="text-white text-4xl font-bold mb-4">Projects</h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto">
            Following projects showcases my skills and experience through
            real-world examples of my work. It reflects my ability to solve
            complex problems, work with different technologies, and manage
            projects effectively.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              className={`group bg-gradient-to-br from-[#1a1a2e] to-[#16213e] rounded-2xl overflow-hidden hover:scale-[1.02] transition-all ${
                project.highlight ? "ring-2 ring-[#0EA5E9]" : ""
              }`}
            >
              {/* Image Placeholder */}
              <div className="w-full h-48 bg-gray-300 rounded-t-2xl" />

              {/* Content */}
              <div className="p-6">
                <h3 className="text-white text-xl font-semibold mb-3">
                  {project.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {project.description}
                </p>

                {/* Skills */}
                <div className="flex flex-wrap gap-2">
                  <span className="text-sm font-medium text-white">
                    Key skill:
                  </span>
                  {project.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="text-[#0EA5E9] text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};