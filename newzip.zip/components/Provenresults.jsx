"use client";

import React from "react";

export default function ProvenResults(){
  const results = [
    {
      value: "25+",
      label: "Projects Delivered",
      description: "Successfully completed projects across industries",
      gradient: "from-yellow-400 to-yellow-600",
    },
    {
      value: "98%",
      label: "Client Satisfaction",
      description: "Average client rating across all platforms",
      gradient: "from-pink-400 via-purple-400 to-orange-400",
    },
    {
      value: "99.9%",
      label: "Average Uptime",
      description: "System reliability across all deployments",
      gradient: "from-orange-400 to-orange-600",
    },
    {
      value: "80%",
      label: "Faster Deployments",
      description: "Reduction in deployment time via CI/CD",
      gradient: "from-green-400 to-teal-500",
    },
    {
      value: "25+",
      label: "Projects Delivered",
      description: "Successfully completed projects across industries",
      gradient: "from-purple-400 via-pink-400 to-purple-600",
    },
    {
      value: "85%",
      label: "Client Retention",
      description: "Long-term partnerships and repeat clients",
      gradient: "from-cyan-400 via-teal-400 to-blue-500",
    },
  ];

  return (
    <section className="bg-gradient-to-b from-[#1e1b2e] to-[#252140] py-20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <p className="text-[#F59E0B] text-sm uppercase tracking-wide mb-2">
            TRACK RECORD
          </p>
          <h2 className="text-white text-4xl font-bold mb-4">
            Proven Results
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Measurable outcomes that drive business growth and operational
            efficiency
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {results.map((result, index) => (
            <div
              key={index}
              className="bg-[#2a2540] border border-[#3a3549] rounded-xl p-8 flex flex-col items-center text-center hover:border-[#F59E0B]/50 transition-all"
            >
              {/* Icon with gradient */}
              <div
                className={`w-16 h-16 bg-gradient-to-br ${result.gradient} rounded-2xl mb-4`}
              />

              {/* Value */}
              <div className="text-5xl font-bold text-white mb-2">
                {result.value}
              </div>

              {/* Label */}
              <div className="text-lg font-semibold text-white mb-2">
                {result.label}
              </div>

              {/* Description */}
              <div className="text-sm text-gray-400">
                {result.description}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};