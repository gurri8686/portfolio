import React from "react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#1a1625] border-t border-[#2a2540]">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left - Brand */}
          <div>
            <h3 className="text-white text-2xl font-semibold mb-3">
              Gurpreet Singh
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Transforming Business Ideas into Scalable Digital Products That
              Drive Revenue
            </p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-green-400 text-sm">
                Available for New Projects
              </span>
            </div>
          </div>

          {/* Middle - Navigation */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">
              Navigation
            </h4>
            <ul className="space-y-2">
              <li>
                <a
                  href="#home"
                  className="text-gray-400 hover:text-white text-sm transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#projects"
                  className="text-gray-400 hover:text-white text-sm transition-colors"
                >
                  Projects
                </a>
              </li>
              <li>
                <a
                  href="#testimonials"
                  className="text-gray-400 hover:text-white text-sm transition-colors"
                >
                  Testimonials
                </a>
              </li>
              <li>
                <a
                  href="#about"
                  className="text-gray-400 hover:text-white text-sm transition-colors"
                >
                  About
                </a>
              </li>
            </ul>
          </div>

          {/* Right - Contact */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">
              Get in Touch
            </h4>
            <div className="space-y-3">
              <a
                href="mailto:contact@gurpreet.dev"
                className="text-gray-400 hover:text-white text-sm block transition-colors flex items-center gap-2"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
                contact@gurpreet.dev
              </a>
              <p className="text-gray-500 text-sm flex items-center gap-2">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                Response time: &lt; 2 hours
              </p>
              <p className="text-gray-500 text-sm flex items-center gap-2">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                Timezone: IST (UTC+5:30)
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#2a2540] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © {currentYear} gurpreet. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <span>Available on</span>
            <span className="text-white">Upwork</span>
            <span>•</span>
            <span className="text-white">Toptal</span>
            <span>•</span>
            <span className="text-white">Fiverr Pro</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;