import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { Projects } from "@/components/Projects";
import ProvenResults from "@/components/Provenresults";
import Technologies from "@/components/Technologies";
export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        
      </main>
      <Footer />
    </>
  );
}