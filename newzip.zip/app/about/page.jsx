import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function About() {
  const skills = {
    "Frontend Development": [
      "React.js",
      "Next.js",
      "Vue.js",
      "TypeScript",
      "Tailwind CSS",
      "HTML5/CSS3",
    ],
    "Backend Development": [
      "Node.js",
      "Express.js",
      "Python",
      "Django",
      "REST APIs",
      "GraphQL",
    ],
    "Database & Cloud": [
      "PostgreSQL",
      "MongoDB",
      "Redis",
      "AWS",
      "Docker",
      "Kubernetes",
    ],
    "Tools & Others": [
      "Git",
      "CI/CD",
      "Agile/Scrum",
      "Testing",
      "UI/UX Design",
      "System Architecture",
    ],
  };

  const experience = [
    {
      year: "2020 - Present",
      role: "Senior Full-Stack Developer",
      company: "Tech Innovations Inc.",
      description:
        "Leading development of enterprise-scale web applications, mentoring junior developers, and architecting scalable solutions for Fortune 500 clients.",
    },
    {
      year: "2017 - 2020",
      role: "Full-Stack Developer",
      company: "Digital Solutions Ltd.",
      description:
        "Developed and maintained multiple client projects, implemented CI/CD pipelines, and improved application performance by 40%.",
    },
    {
      year: "2014 - 2017",
      role: "Frontend Developer",
      company: "StartUp Labs",
      description:
        "Built responsive web applications, collaborated with design teams, and contributed to open-source projects.",
    },
  ];

  const education = [
    {
      year: "2010 - 2014",
      degree: "Bachelor of Computer Science",
      institution: "University Name",
      description:
        "Graduated with honors. Specialized in Software Engineering and Data Structures.",
    },
  ];

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-stone-950 pt-20">
        {/* Header */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              About Me
            </h1>
            <p className="text-xl text-stone-400 leading-relaxed">
              I am a passionate Full-Stack Developer with over 10 years of
              experience building scalable web applications and leading
              development teams. I love turning complex problems into elegant,
              user-friendly solutions.
            </p>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-12 px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-stone-900 border border-stone-800 rounded-xl p-8">
              <h2 className="text-3xl font-bold text-white mb-6">My Story</h2>
              <div className="space-y-4 text-stone-300 leading-relaxed">
                <p>
                  My journey in software development began over a decade ago when
                  I wrote my first line of code. Since then, I have been fortunate
                  to work with amazing teams on projects ranging from small
                  startups to Fortune 500 companies.
                </p>
                <p>
                  I specialize in building full-stack web applications using
                  modern JavaScript frameworks. My approach combines technical
                  expertise with a deep understanding of user needs, always
                  focusing on creating solutions that are both powerful and
                  intuitive.
                </p>
                <p>
                  When I am not coding, you can find me contributing to open-source
                  projects, writing technical articles, or mentoring aspiring
                  developers. I believe in continuous learning and staying updated
                  with the latest technologies and best practices.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section className="py-12 px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              Technical Skills
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(skills).map(([category, items]) => (
                <div
                  key={category}
                  className="bg-stone-900 border border-stone-800 rounded-xl p-6"
                >
                  <h3 className="text-lg font-semibold text-white mb-4">
                    {category}
                  </h3>
                  <ul className="space-y-2">
                    {items.map((skill) => (
                      <li
                        key={skill}
                        className="text-stone-400 text-sm flex items-center gap-2"
                      >
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full" />
                        {skill}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section className="py-12 px-6 lg:px-8 bg-stone-900/50">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-8">Experience</h2>
            <div className="space-y-6">
              {experience.map((exp, index) => (
                <div
                  key={index}
                  className="bg-stone-950 border border-stone-800 rounded-xl p-6 hover:border-blue-500/50 transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
                    <h3 className="text-xl font-semibold text-white">
                      {exp.role}
                    </h3>
                    <span className="text-blue-400 text-sm">{exp.year}</span>
                  </div>
                  <div className="text-stone-400 font-medium mb-3">
                    {exp.company}
                  </div>
                  <p className="text-stone-300 leading-relaxed">
                    {exp.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section className="py-12 px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-8">Education</h2>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <div
                  key={index}
                  className="bg-stone-900 border border-stone-800 rounded-xl p-6"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
                    <h3 className="text-xl font-semibold text-white">
                      {edu.degree}
                    </h3>
                    <span className="text-blue-400 text-sm">{edu.year}</span>
                  </div>
                  <div className="text-stone-400 font-medium mb-3">
                    {edu.institution}
                  </div>
                  <p className="text-stone-300 leading-relaxed">
                    {edu.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-gradient-to-r from-blue-500/10 to-purple-600/10 border border-blue-500/20 rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">
                Lets Build Something Amazing
              </h2>
              <p className="text-stone-400 mb-8">
                I am always open to discussing new projects and opportunities.
              </p>
              <a
                href="https://teams.microsoft.com/l/chat/0/0?users=YOUR_TEAMS_ID"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-blue-500/50 transition-all hover:scale-105"
              >
                Get in Touch
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}