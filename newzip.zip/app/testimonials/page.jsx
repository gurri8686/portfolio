import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Image from "next/image";

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "CTO",
      company: "TechCorp Inc.",
      avatar: "https://i.pravatar.cc/150?img=1",
      content:
        "Working with this developer was an absolute game-changer for our product. Their technical expertise, combined with exceptional communication skills, resulted in a platform that exceeded all our expectations. The attention to detail and commitment to quality is unmatched.",
      rating: 5,
      project: "Enterprise Dashboard",
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Product Manager",
      company: "InnovateLabs",
      avatar: "https://i.pravatar.cc/150?img=12",
      content:
        "An outstanding professional who brings both technical skill and strategic thinking to every project. They consistently delivered high-quality work ahead of schedule and helped us navigate complex technical challenges with ease. Highly recommend!",
      rating: 5,
      project: "AI Content Platform",
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "CEO",
      company: "StartupVentures",
      avatar: "https://i.pravatar.cc/150?img=5",
      content:
        "Their expertise in full-stack development was instrumental in launching our MVP. Great communicator, proactive problem-solver, and a true professional. Our application runs smoothly thanks to their solid architecture and clean code.",
      rating: 5,
      project: "Healthcare Platform",
    },
    {
      id: 4,
      name: "David Park",
      role: "Founder",
      company: "DigitalFlow",
      avatar: "https://i.pravatar.cc/150?img=13",
      content:
        "Exceptional work ethic and technical abilities. They transformed our outdated system into a modern, scalable platform. The project was delivered on time, within budget, and the final product surpassed our requirements in every way.",
      rating: 5,
      project: "E-Commerce Platform",
    },
    {
      id: 5,
      name: "Jennifer Lee",
      role: "VP of Engineering",
      company: "CloudSolutions",
      avatar: "https://i.pravatar.cc/150?img=9",
      content:
        "A rare find in the development world - someone who combines deep technical knowledge with excellent soft skills. They mentored our junior developers while delivering complex features. Would work with them again in a heartbeat.",
      rating: 5,
      project: "Project Management Tool",
    },
    {
      id: 6,
      name: "Robert Taylor",
      role: "Director",
      company: "FinTech Innovations",
      avatar: "https://i.pravatar.cc/150?img=15",
      content:
        "Impressed by their ability to understand complex business requirements and translate them into elegant technical solutions. They're not just a developer - they're a valuable technology partner who genuinely cares about project success.",
      rating: 5,
      project: "Financial Dashboard",
    },
  ];

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-stone-950 pt-20">
        {/* Header */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              Client Testimonials
            </h1>
            <p className="text-xl text-stone-400 max-w-3xl mx-auto">
              Dont just take my word for it. Here is what clients and colleagues
              have to say about working with me on various projects.
            </p>
          </div>
        </section>

        {/* Testimonials Grid */}
        <section className="pb-20 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial) => (
                <TestimonialCard key={testimonial.id} testimonial={testimonial} />
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 px-6 lg:px-8 bg-stone-900/50">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                  98%
                </div>
                <div className="text-stone-400">Client Satisfaction</div>
              </div>
              <div>
                <div className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                  30+
                </div>
                <div className="text-stone-400">Happy Clients</div>
              </div>
              <div>
                <div className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                  50+
                </div>
                <div className="text-stone-400">Projects Delivered</div>
              </div>
              <div>
                <div className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                  5.0
                </div>
                <div className="text-stone-400">Average Rating</div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function TestimonialCard({ testimonial }) {
  return (
    <div className="bg-stone-900 border border-stone-800 rounded-xl p-6 hover:border-blue-500/50 transition-all flex flex-col">
      {/* Quote Icon */}
      <div className="text-blue-400 mb-4">
        <svg className="w-8 h-8 opacity-50" fill="currentColor" viewBox="0 0 24 24">
          <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
        </svg>
      </div>

      {/* Content */}
      <p className="text-stone-300 leading-relaxed mb-6 flex-grow">
        {testimonial.content}
      </p>

      {/* Rating */}
      <div className="flex gap-1 mb-4">
        {[...Array(testimonial.rating)].map((_, i) => (
          <svg
            key={i}
            className="w-5 h-5 text-yellow-500"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>

      {/* Project Tag */}
      <div className="mb-4">
        <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-xs rounded-full">
          {testimonial.project}
        </span>
      </div>

      {/* Author */}
      <div className="flex items-center gap-4 border-t border-stone-800 pt-4">
        <div className="relative w-12 h-12 rounded-full overflow-hidden">
          <Image
            src={testimonial.avatar}
            alt={testimonial.name}
            fill
            className="object-cover"
          />
        </div>
        <div>
          <div className="font-semibold text-white">{testimonial.name}</div>
          <div className="text-sm text-stone-400">
            {testimonial.role} at {testimonial.company}
          </div>
        </div>
      </div>
    </div>
  );
}